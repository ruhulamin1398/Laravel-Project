<!doctype html>

<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(session('successMsg')): ?>
	<div class="alert alert-dismissible alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Well done!</strong> <?php echo e(session('successMsg')); ?>

	</div>
	<?php endif; ?>

<table class="table table-striped table-hover table-bordered ">
	<thead>
		<tr>
			<th scope="col">#</th>
			<th scope="col">Problem name</th>
			<th scope="col">Online judge</th>
			<th scope="col">Problem Link</th>
			<th scope="col" class="text-center">Action</th>
		</tr>
	</thead>
	<tbody>
	<?php  $i=1;    ?>
	
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th scope="row"><?php echo e($i++); ?> </th>
			<td><?php echo e($student->problemName); ?> </td>
			<td> <?php echo e($student->onlineJudge); ?> </td>
			<td> <?php echo e($student->link); ?> </td>
			<td class="text-center"> <a href="<?php echo e(route('edit',  $student->id )); ?> " class="btn btn-primary btn-raised btn-sm">
				<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
			</a>

			<form method="POST"  action ="<?php echo e(route('destroy',  $student->id )); ?> "  id="delete-form-<?php echo e($student->id); ?>"   style="display:none; " >
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field("delete")); ?>

			</form>




			<button   onclick="if(confirm('are you sure to delete this')){
				document.getElementById('delete-form-<?php echo e($student->id); ?>').submit();

			}
			else{
				event.preventDefault();

			}

			" class="btn btn-danger btn-sm btn-raised" >
				<i class="fa fa-trash" aria-hidden="true">
				
				</i>
			</button>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($students->links()); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel-Project\schedule OJ problem (for programmer) laravel project\resources\views/welcome.blade.php ENDPATH**/ ?>