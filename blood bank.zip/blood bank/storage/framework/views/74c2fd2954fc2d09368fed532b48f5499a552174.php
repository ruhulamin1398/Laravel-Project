<?php $__env->startSection("content"); ?>
<div class="container">

		<?php if($errors->any()): ?>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="alert alert-dismissible alert-danger">
				  <button type="button" class="close" data-dismiss="alert">×</button>
				  <strong>Oh snap!</strong><?php echo e($error); ?>

				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>




	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panei-title"> Add new </h3>
			
			<div class="panel-body">
				<form class="form-horizontal" action="<?php echo e(route('store')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<fieldset>
						<div class="form-group">
							<label for="problemName" class="col-md-2 control-label">Problem Name</label>
							<div class="col-md-10">
								<input type="text" class="form-control" name="problemName" placeholder="Problem Name">
							</div>
						</div>
						<div class="form-group">
							<label for="onlineJudge" class="col-md-2 control-label">Online judge</label>
							<div class="col-md-10">
								<input type="text" class="form-control" name="onlineJudge" placeholder="Online Judge">
							</div>
						</div>
						
						<div class="form-group">
							<label for="link" class="col-md-2 control-label">Problem link</label>
							<div class="col-md-10">
								<input type="text" class="form-control" name="link" placeholder="Problem link">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-10 col-md-offset-2">
								<button type="button" class="btn btn-default">Cancel</button>
								<button type="submit" class="btn btn-primary">Submit</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel-Project\schedule OJ problem (for programmer) laravel project\resources\views/create.blade.php ENDPATH**/ ?>